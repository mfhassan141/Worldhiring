import { Link } from "@tanstack/react-router";
import { Search, Mail, Bell, Menu, MapPin, Briefcase, Users, FileText, Building2, TrendingUp, Globe } from "lucide-react";
import logo from "@/assets/worldhiring-logo.jpg.asset.json";
import type { ReactNode } from "react";

const topNav = [
  { label: "Home", to: "/" },
  { label: "Jobs", to: "/services" },
  { label: "Companies", to: "/services" },
  { label: "Services", to: "/services" },
  { label: "Salary Tool", to: "/services" },
  { label: "About", to: "/about" },
];

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[#f5f5f7] text-slate-900">
      {/* Top utility bar */}
      <div className="bg-white border-b">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between px-4 py-2 text-xs">
          <div className="flex items-center gap-4 text-slate-600">
            <span className="hidden sm:flex items-center gap-1"><Globe className="h-3 w-3" /> Worldwide</span>
            <span className="hidden md:inline">Mon–Sat 9:00–18:00</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/register/employer" className="text-slate-700 hover:text-violet-700">Post a Job</Link>
            <Link to="/register/employee" className="text-slate-700 hover:text-violet-700">Sign In</Link>
          </div>
        </div>
      </div>

      {/* Main header (Yahoo-style) */}
      <header className="bg-white border-b">
        <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 py-3">
          <Link to="/" className="shrink-0">
            <img src={logo.url} alt="World Hiring" className="h-10 w-auto" />
          </Link>

          <div className="hidden md:flex flex-1 items-center gap-2">
            <div className="flex w-full items-center rounded-md border border-violet-500 bg-white">
              <input
                placeholder="Search jobs, companies, skills..."
                className="flex-1 px-3 py-2 text-sm outline-none rounded-l-md"
              />
              <div className="flex items-center gap-1 border-l px-2 text-slate-500">
                <MapPin className="h-4 w-4" />
                <input placeholder="City / Country" className="w-32 py-2 text-sm outline-none" />
              </div>
              <button className="flex items-center gap-1 rounded-r-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700">
                <Search className="h-4 w-4" /> Search
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-600">
            <button className="hidden sm:block p-2 hover:text-violet-700"><Mail className="h-5 w-5" /></button>
            <button className="hidden sm:block p-2 hover:text-violet-700"><Bell className="h-5 w-5" /></button>
            <button className="md:hidden p-2"><Menu className="h-5 w-5" /></button>
          </div>
        </div>

        {/* Category nav */}
        <nav className="bg-violet-700 text-white">
          <div className="mx-auto flex max-w-[1400px] items-center gap-1 overflow-x-auto px-2">
            {topNav.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="whitespace-nowrap px-3 py-2 text-sm font-medium hover:bg-violet-800"
              >
                {item.label}
              </Link>
            ))}
            <span className="mx-2 h-4 w-px bg-violet-500" />
            <Link to="/register/employer" className="whitespace-nowrap px-3 py-2 text-sm font-medium hover:bg-violet-800">For Employers</Link>
            <Link to="/register/employee" className="whitespace-nowrap px-3 py-2 text-sm font-medium hover:bg-violet-800">For Job Seekers</Link>
          </div>
        </nav>
      </header>

      <main className="mx-auto max-w-[1400px] px-4 py-6">{children}</main>

      <footer className="mt-10 bg-slate-900 text-slate-300">
        <div className="mx-auto grid max-w-[1400px] gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <img src={logo.url} alt="World Hiring" className="h-10 w-auto bg-white p-1 rounded" />
            <p className="mt-3 text-sm">Bridge to Job Opportunities. Connecting talent and employers worldwide.</p>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">For Employers</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/register/employer">Post a Job</Link></li>
              <li><Link to="/services">Executive Headhunting</Link></li>
              <li><Link to="/services">Express Hiring</Link></li>
              <li><Link to="/services">CV Bank</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">For Job Seekers</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/register/employee">Create Profile</Link></li>
              <li><Link to="/services">Online Job Search</Link></li>
              <li><Link to="/services">Resume Templates</Link></li>
              <li><Link to="/services">Talent Trends</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">Company</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/services">Services</Link></li>
              <li><a href="#">Contact</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 py-4 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} World Hiring. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

export const serviceIcons = { Briefcase, Users, FileText, Building2, TrendingUp };
