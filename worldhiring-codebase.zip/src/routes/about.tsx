import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { Target, Eye, Heart, Globe, Users, Award } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us – World Hiring" },
      { name: "description", content: "Learn about World Hiring – a global recruitment agency bridging talent and opportunity." },
      { property: "og:title", content: "About World Hiring" },
      { property: "og:description", content: "Global recruitment agency bridging talent with opportunity." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <SiteLayout>
      <div className="overflow-hidden rounded-xl bg-gradient-to-r from-violet-700 to-indigo-700 p-10 text-white">
        <h1 className="text-4xl font-extrabold">About World Hiring</h1>
        <p className="mt-3 max-w-2xl text-violet-100">We are a global recruitment agency dedicated to connecting talented professionals with leading employers around the world. Our mission is to be the bridge to job opportunities — locally and internationally.</p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        {[
          { icon: Target, t: "Our Mission", d: "Empower job seekers and employers with smart, fast, and reliable recruitment solutions." },
          { icon: Eye, t: "Our Vision", d: "To become the world's most trusted bridge between talent and opportunity." },
          { icon: Heart, t: "Our Values", d: "Integrity, transparency, speed, and a genuine commitment to client success." },
        ].map(x => (
          <div key={x.t} className="rounded-lg bg-white p-6 shadow-sm">
            <x.icon className="h-8 w-8 text-violet-600" />
            <h3 className="mt-3 text-lg font-bold">{x.t}</h3>
            <p className="mt-1 text-sm text-slate-600">{x.d}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="rounded-lg bg-white p-6 shadow-sm">
          <h2 className="text-xl font-bold">Who We Are</h2>
          <p className="mt-3 text-sm leading-relaxed text-slate-700">World Hiring is a full-service recruitment agency working across multiple regions including the GCC, South Asia, Europe, and South East Asia. We specialize in executive search, express hiring, and verified employment services for industries ranging from IT and engineering to healthcare and construction.</p>
          <p className="mt-3 text-sm leading-relaxed text-slate-700">With a robust CV bank, comprehensive salary analytics, and a vetted employer network, we deliver quality matches at the speed modern business demands.</p>
        </div>
        <div className="rounded-lg bg-white p-6 shadow-sm">
          <h2 className="text-xl font-bold">By the Numbers</h2>
          <div className="mt-4 grid grid-cols-2 gap-4">
            {[
              { icon: Globe, n: "30+", l: "Countries Served" },
              { icon: Users, n: "150K+", l: "Active Candidates" },
              { icon: Award, n: "2K+", l: "Hiring Partners" },
              { icon: Target, n: "24–48h", l: "Express Placement" },
            ].map(s => (
              <div key={s.l} className="rounded-md border p-4 text-center">
                <s.icon className="mx-auto h-6 w-6 text-violet-600" />
                <div className="mt-2 text-2xl font-extrabold">{s.n}</div>
                <div className="text-xs text-slate-500">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </SiteLayout>
  );
}
