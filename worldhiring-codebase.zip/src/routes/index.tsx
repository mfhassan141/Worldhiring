import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { Briefcase, Building2, Search, FileText, TrendingUp, Users, Zap, ShieldCheck, MapPin, Clock, Star } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "World Hiring – Bridge to Job Opportunities" },
      { name: "description", content: "Find jobs, hire talent, and explore salary insights worldwide with World Hiring." },
      { property: "og:title", content: "World Hiring – Bridge to Job Opportunities" },
      { property: "og:description", content: "Find jobs, hire talent, and explore salary insights worldwide with World Hiring." },
    ],
  }),
  component: Home,
});

const featuredJobs = [
  { title: "Senior React Developer", company: "TechNova Ltd.", location: "Dubai, UAE", tag: "Premium", time: "2h ago" },
  { title: "Marketing Manager", company: "BrightAds", location: "London, UK", tag: "Featured", time: "5h ago" },
  { title: "Mechanical Engineer", company: "ArabBuild Co.", location: "Riyadh, KSA", tag: "Recent", time: "1d ago" },
  { title: "Data Analyst", company: "FinCore", location: "Karachi, PK", tag: "Premium", time: "1d ago" },
  { title: "HR Business Partner", company: "GlobalCorp", location: "Singapore", tag: "Featured", time: "2d ago" },
  { title: "Civil Foreman", company: "BuildPro", location: "Doha, QA", tag: "Recent", time: "3d ago" },
];

const tagColor: Record<string, string> = {
  Premium: "bg-amber-100 text-amber-800",
  Featured: "bg-violet-100 text-violet-800",
  Recent: "bg-emerald-100 text-emerald-800",
};

const trending = ["Remote Jobs", "AI Engineer", "Gulf Hiring", "Express Hiring", "Salary Report 2026", "Executive Search"];

function Home() {
  return (
    <SiteLayout>
      {/* Yahoo-style 3-column grid */}
      <div className="grid gap-6 lg:grid-cols-[260px_1fr_320px]">
        {/* Left sidebar */}
        <aside className="space-y-4">
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h3 className="mb-3 text-sm font-bold text-slate-900">Browse Categories</h3>
            <ul className="space-y-2 text-sm">
              {["IT & Software","Engineering","Sales & Marketing","Healthcare","Finance & Banking","Construction","Education","Hospitality","Oil & Gas","Logistics"].map(c => (
                <li key={c}><a className="flex items-center justify-between hover:text-violet-700" href="#"><span>{c}</span><span className="text-xs text-slate-400">{Math.floor(Math.random()*900)+100}</span></a></li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg bg-gradient-to-br from-violet-600 to-indigo-700 p-4 text-white shadow-sm">
            <h3 className="font-bold">Express Hiring</h3>
            <p className="mt-1 text-sm text-violet-100">Get qualified candidates in 24–48 hours.</p>
            <Link to="/register/employer" className="mt-3 inline-block rounded bg-white px-3 py-1.5 text-xs font-semibold text-violet-700">Request Now</Link>
          </div>
        </aside>

        {/* Center column */}
        <section className="space-y-6">
          {/* Hero */}
          <div className="overflow-hidden rounded-xl bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 p-8 text-white shadow">
            <h1 className="text-3xl font-extrabold sm:text-4xl">Bridge to Job Opportunities</h1>
            <p className="mt-2 max-w-xl text-violet-100">Search thousands of jobs across the globe. Verified employers. Real opportunities.</p>
            <div className="mt-5 flex flex-col gap-2 rounded-lg bg-white p-2 text-slate-700 sm:flex-row">
              <div className="flex flex-1 items-center gap-2 px-2"><Search className="h-4 w-4 text-slate-400" /><input className="w-full py-2 outline-none" placeholder="Job title or keyword" /></div>
              <div className="flex flex-1 items-center gap-2 border-t px-2 sm:border-l sm:border-t-0"><MapPin className="h-4 w-4 text-slate-400" /><input className="w-full py-2 outline-none" placeholder="Country / City" /></div>
              <button className="rounded bg-slate-900 px-5 py-2 font-semibold text-white hover:bg-black">Find Jobs</button>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-violet-100">Trending:</span>
              {trending.map(t => <span key={t} className="rounded-full bg-white/15 px-2 py-1">{t}</span>)}
            </div>
          </div>

          {/* Featured jobs */}
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-bold">Featured Jobs</h2>
              <Link to="/services" className="text-sm text-violet-700 hover:underline">View all</Link>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {featuredJobs.map(j => (
                <div key={j.title} className="rounded-md border p-3 hover:border-violet-400 hover:shadow-sm">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-slate-900">{j.title}</h3>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${tagColor[j.tag]}`}>{j.tag}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-600">{j.company}</p>
                  <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{j.location}</span>
                    <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{j.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Services snapshot */}
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              { icon: Zap, t: "Express Hiring", d: "Talent in 24–48 hours" },
              { icon: ShieldCheck, t: "Verified Profiles", d: "Trusted background checks" },
              { icon: TrendingUp, t: "Salary Reports", d: "Country & city insights" },
            ].map(s => (
              <div key={s.t} className="rounded-lg bg-white p-4 shadow-sm">
                <s.icon className="h-6 w-6 text-violet-600" />
                <h3 className="mt-2 font-semibold">{s.t}</h3>
                <p className="text-sm text-slate-600">{s.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Right sidebar */}
        <aside className="space-y-4">
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h3 className="mb-2 font-bold">Join World Hiring</h3>
            <div className="space-y-2">
              <Link to="/register/employee" className="flex items-center gap-2 rounded-md border p-2 text-sm hover:border-violet-400"><Users className="h-4 w-4 text-violet-600" /> Register as Job Seeker</Link>
              <Link to="/register/employer" className="flex items-center gap-2 rounded-md border p-2 text-sm hover:border-violet-400"><Building2 className="h-4 w-4 text-violet-600" /> Register as Employer</Link>
            </div>
          </div>
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h3 className="mb-3 font-bold">Top Hiring Companies</h3>
            <ul className="space-y-3 text-sm">
              {["TechNova","FinCore","GlobalCorp","BuildPro","ArabBuild","BrightAds"].map((c,i)=>(
                <li key={c} className="flex items-center justify-between">
                  <span className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded bg-violet-100 text-xs font-bold text-violet-700">{c[0]}</span>{c}</span>
                  <span className="flex items-center gap-1 text-xs text-amber-500"><Star className="h-3 w-3 fill-amber-500" />{(4 + Math.random()).toFixed(1)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h3 className="mb-3 font-bold">Region Talent Trends</h3>
            <ul className="space-y-2 text-sm">
              {[
                { r: "GCC", v: "+12%" },
                { r: "South Asia", v: "+9%" },
                { r: "Europe", v: "+4%" },
                { r: "SE Asia", v: "+7%" },
              ].map(x=>(
                <li key={x.r} className="flex items-center justify-between"><span>{x.r}</span><span className="font-semibold text-emerald-600">{x.v}</span></li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </SiteLayout>
  );
}
