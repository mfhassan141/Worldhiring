import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { UserCheck } from "lucide-react";

export const Route = createFileRoute("/register/employee")({
  head: () => ({
    meta: [
      { title: "Job Seeker Registration – World Hiring" },
      { name: "description", content: "Create your professional profile and apply to jobs worldwide on World Hiring." },
      { property: "og:title", content: "Job Seeker Registration – World Hiring" },
      { property: "og:description", content: "Create your profile and start applying to jobs." },
    ],
  }),
  component: EmployeeRegister,
});

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
      <input {...props} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-200" />
    </label>
  );
}

function EmployeeRegister() {
  return (
    <SiteLayout>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <form
          onSubmit={(e) => { e.preventDefault(); alert("Profile created (UI demo)"); }}
          className="rounded-xl bg-white p-6 shadow-sm"
        >
          <div className="mb-6 flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-lg bg-violet-100 text-violet-700"><UserCheck /></div>
            <div>
              <h1 className="text-2xl font-bold">Job Seeker Registration</h1>
              <p className="text-sm text-slate-600">Build your verified profile and apply to jobs in one click.</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="First Name" required />
            <Field label="Last Name" required />
            <Field label="Email" type="email" required />
            <Field label="Phone" placeholder="+.. ..." />
            <Field label="Country" placeholder="Pakistan" />
            <Field label="City" placeholder="Karachi" />
            <Field label="Current Job Title" placeholder="Software Engineer" />
            <Field label="Years of Experience" type="number" placeholder="3" />
            <Field label="Industry" placeholder="IT / Healthcare / Finance..." />
            <Field label="Expected Salary" placeholder="USD / month" />
            <Field label="Password" type="password" required />
            <Field label="Confirm Password" type="password" required />
          </div>

          <label className="mt-4 block">
            <span className="mb-1 block text-sm font-medium text-slate-700">Key Skills</span>
            <input className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-200" placeholder="React, Node.js, Project Management..." />
          </label>

          <label className="mt-4 block">
            <span className="mb-1 block text-sm font-medium text-slate-700">Upload CV (PDF/DOCX)</span>
            <input type="file" accept=".pdf,.doc,.docx" className="w-full rounded-md border border-dashed border-slate-300 px-3 py-6 text-sm" />
          </label>

          <label className="mt-4 flex items-start gap-2 text-sm text-slate-600">
            <input type="checkbox" required className="mt-1" />
            I agree to World Hiring's Terms of Service and Privacy Policy.
          </label>

          <button className="mt-6 w-full rounded-md bg-violet-600 px-4 py-3 font-semibold text-white hover:bg-violet-700">Create My Profile</button>
        </form>

        <aside className="space-y-4">
          <div className="rounded-xl bg-gradient-to-br from-violet-600 to-indigo-700 p-5 text-white">
            <h3 className="font-bold">Member benefits</h3>
            <ul className="mt-3 space-y-2 text-sm text-violet-100">
              <li>• Verified profile badge</li>
              <li>• Professional resume templates</li>
              <li>• One-click job applications</li>
              <li>• Region talent trend reports</li>
            </ul>
          </div>
          <div className="rounded-xl bg-white p-5 shadow-sm">
            <h4 className="font-semibold">Already a member?</h4>
            <p className="mt-1 text-sm text-slate-600">Sign in to view your applications.</p>
            <button className="mt-3 w-full rounded-md border border-violet-600 px-3 py-2 text-sm font-semibold text-violet-700 hover:bg-violet-50">Sign In</button>
          </div>
        </aside>
      </div>
    </SiteLayout>
  );
}
