import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { Building2 } from "lucide-react";

export const Route = createFileRoute("/register/employer")({
  head: () => ({
    meta: [
      { title: "Employer Registration – World Hiring" },
      { name: "description", content: "Register your company on World Hiring to post jobs and hire top talent." },
      { property: "og:title", content: "Employer Registration – World Hiring" },
      { property: "og:description", content: "Register your company and start hiring." },
    ],
  }),
  component: EmployerRegister,
});

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
      <input {...props} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-200" />
    </label>
  );
}

function EmployerRegister() {
  return (
    <SiteLayout>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <form
          onSubmit={(e) => { e.preventDefault(); alert("Registration submitted (UI demo)"); }}
          className="rounded-xl bg-white p-6 shadow-sm"
        >
          <div className="mb-6 flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-lg bg-violet-100 text-violet-700"><Building2 /></div>
            <div>
              <h1 className="text-2xl font-bold">Employer Registration</h1>
              <p className="text-sm text-slate-600">Create your company account and start posting jobs.</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Company Name" placeholder="Acme Corp" required />
            <Field label="Industry" placeholder="IT / Engineering / Healthcare..." />
            <Field label="Company Size" placeholder="1-10, 11-50, 51-200..." />
            <Field label="Website" placeholder="https://..." />
            <Field label="Country" placeholder="UAE" />
            <Field label="City" placeholder="Dubai" />
            <Field label="Contact Person" placeholder="Full name" required />
            <Field label="Designation" placeholder="HR Manager" />
            <Field label="Work Email" type="email" placeholder="hr@company.com" required />
            <Field label="Phone" placeholder="+971 ..." />
            <Field label="Password" type="password" required />
            <Field label="Confirm Password" type="password" required />
          </div>

          <label className="mt-4 block">
            <span className="mb-1 block text-sm font-medium text-slate-700">Company Description</span>
            <textarea rows={4} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-200" placeholder="Brief about your company..." />
          </label>

          <label className="mt-4 flex items-start gap-2 text-sm text-slate-600">
            <input type="checkbox" required className="mt-1" />
            I agree to World Hiring's Terms of Service and Privacy Policy.
          </label>

          <button className="mt-6 w-full rounded-md bg-violet-600 px-4 py-3 font-semibold text-white hover:bg-violet-700">Create Employer Account</button>
        </form>

        <aside className="space-y-4">
          <div className="rounded-xl bg-gradient-to-br from-violet-600 to-indigo-700 p-5 text-white">
            <h3 className="font-bold">Why register?</h3>
            <ul className="mt-3 space-y-2 text-sm text-violet-100">
              <li>• Post Premium / Featured jobs</li>
              <li>• Access verified CV Bank</li>
              <li>• Express Hiring in 24–48h</li>
              <li>• Salary & compensation insights</li>
            </ul>
          </div>
          <div className="rounded-xl bg-white p-5 shadow-sm">
            <h4 className="font-semibold">Already registered?</h4>
            <p className="mt-1 text-sm text-slate-600">Sign in to manage your jobs and applications.</p>
            <button className="mt-3 w-full rounded-md border border-violet-600 px-3 py-2 text-sm font-semibold text-violet-700 hover:bg-violet-50">Sign In</button>
          </div>
        </aside>
      </div>
    </SiteLayout>
  );
}
