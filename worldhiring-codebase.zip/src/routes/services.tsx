import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { Megaphone, Building2, Search, ShieldCheck, Database, BarChart3, FileText, UserCheck, Zap, Briefcase, Globe2, Crown } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services – World Hiring" },
      { name: "description", content: "Recruitment, headhunting, CV bank, salary insights, and job seeker services from World Hiring." },
      { property: "og:title", content: "World Hiring Services" },
      { property: "og:description", content: "Recruitment, headhunting, CV bank, salary insights, and job seeker services." },
    ],
  }),
  component: Services,
});

const employerServices = [
  { icon: Megaphone, t: "Job Advertisement & Promotions", d: "Premium, Featured, and Recent job placement options to maximize visibility." },
  { icon: Building2, t: "Company Registration", d: "Get your company verified and listed in our employer directory." },
  { icon: Crown, t: "Executive Headhunting", d: "Targeted search for C-level and senior leadership roles." },
  { icon: Briefcase, t: "Job Facilitation", d: "End-to-end recruitment support from shortlisting to onboarding." },
  { icon: Zap, t: "Express Hiring", d: "Qualified resources delivered in 24–48 hours. T&C apply." },
  { icon: ShieldCheck, t: "Employment Verification", d: "Background, credentials, and reference verification services." },
  { icon: Database, t: "Search CV / CV Bank", d: "Access our verified database of professionals across industries." },
  { icon: BarChart3, t: "Surveys & Reports", d: "Salary Analysis, Salary Tool, Compensation & Benefits by country, city, company." },
];

const seekerServices = [
  { icon: UserCheck, t: "Profile Registration", d: "Create your professional profile in minutes." },
  { icon: Search, t: "Online Job Search", d: "Browse and filter jobs across regions and industries." },
  { icon: ShieldCheck, t: "Verified Profile", d: "Stand out with a World Hiring verified badge." },
  { icon: FileText, t: "Professional Resume Templates", d: "Ready-made templates trusted by recruiters." },
  { icon: Briefcase, t: "Apply Online for a Job", d: "Apply in one click with your profile." },
  { icon: Globe2, t: "Region Talent Trends", d: "Stay ahead with insights on hiring trends in your region." },
];

function Services() {
  return (
    <SiteLayout>
      <div className="rounded-xl bg-gradient-to-r from-violet-700 to-indigo-700 p-8 text-white">
        <h1 className="text-3xl font-extrabold sm:text-4xl">Our Services</h1>
        <p className="mt-2 max-w-2xl text-violet-100">Comprehensive recruitment solutions for employers and a powerful platform for job seekers.</p>
      </div>

      {/* Employers */}
      <section className="mt-8">
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-2xl font-bold">For Employers</h2>
          <Link to="/register/employer" className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700">Register as Employer</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {employerServices.map(s => (
            <div key={s.t} className="rounded-lg border bg-white p-5 shadow-sm transition hover:border-violet-400 hover:shadow">
              <s.icon className="h-7 w-7 text-violet-600" />
              <h3 className="mt-3 font-semibold text-slate-900">{s.t}</h3>
              <p className="mt-1 text-sm text-slate-600">{s.d}</p>
            </div>
          ))}
        </div>

        {/* Ad packages */}
        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          {[
            { name: "Recent", price: "Free", color: "bg-emerald-50 border-emerald-200", btn: "bg-emerald-600 hover:bg-emerald-700", features: ["Standard listing","30-day visibility","Basic stats"] },
            { name: "Featured", price: "$49", color: "bg-violet-50 border-violet-200", btn: "bg-violet-600 hover:bg-violet-700", features: ["Highlighted listing","Top of category","Email blast"] },
            { name: "Premium", price: "$129", color: "bg-amber-50 border-amber-200", btn: "bg-amber-600 hover:bg-amber-700", features: ["Homepage feature","Premium badge","Dedicated recruiter"] },
          ].map(p => (
            <div key={p.name} className={`rounded-lg border p-5 ${p.color}`}>
              <h3 className="text-lg font-bold">{p.name}</h3>
              <div className="mt-1 text-3xl font-extrabold">{p.price}<span className="text-sm font-medium text-slate-500">/post</span></div>
              <ul className="mt-3 space-y-1 text-sm text-slate-700">
                {p.features.map(f => <li key={f}>• {f}</li>)}
              </ul>
              <button className={`mt-4 w-full rounded-md px-3 py-2 text-sm font-semibold text-white ${p.btn}`}>Choose {p.name}</button>
            </div>
          ))}
        </div>
      </section>

      {/* Job Seekers */}
      <section className="mt-10">
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-2xl font-bold">For Job Seekers</h2>
          <Link to="/register/employee" className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700">Register as Job Seeker</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {seekerServices.map(s => (
            <div key={s.t} className="rounded-lg border bg-white p-5 shadow-sm transition hover:border-violet-400 hover:shadow">
              <s.icon className="h-7 w-7 text-violet-600" />
              <h3 className="mt-3 font-semibold text-slate-900">{s.t}</h3>
              <p className="mt-1 text-sm text-slate-600">{s.d}</p>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
